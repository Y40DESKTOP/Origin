/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#ifndef shareregion__
#define shareregion__



#endif /* shareregion__ */ 
